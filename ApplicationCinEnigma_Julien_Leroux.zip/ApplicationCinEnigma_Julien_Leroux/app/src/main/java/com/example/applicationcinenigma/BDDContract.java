package com.example.applicationcinenigma;

import android.provider.BaseColumns;

public class BDDContract {
    public static final class BDDEntry implements BaseColumns {

        public static final String TABLE_NAME = "bdd";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_DATE = "date";
        public static final String COLUMN_TIME = "time";
        public static final String COLUMN_SCENARIO = "scenario";
        public static final String COLUMN_REALISATION = "realisation";
        public static final String COLUMN_MUSIC = "music";
        public static final String COLUMN_DESCRIPTION = "description";



    }

}
