package com.example.applicationcinenigma;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText filmtitle;
    EditText music;
    EditText date;
    EditText time;
    EditText scenario;
    EditText realisation;
    EditText description;
    Button button;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        filmtitle = (EditText ) findViewById(R.id.filmtitle);
        music = (EditText) findViewById(R.id.music);
        date = (EditText) findViewById(R.id.date);
        time = (EditText) findViewById(R.id.time);
        scenario = (EditText) findViewById(R.id.scenario);
        realisation = (EditText) findViewById(R.id.realisation);
        description = (EditText) findViewById(R.id.description);
        button = (Button) findViewById(R.id.button);

    }



}